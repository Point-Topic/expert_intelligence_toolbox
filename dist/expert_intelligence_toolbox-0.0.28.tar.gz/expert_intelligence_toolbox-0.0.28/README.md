# Expert Intelligence Toolbox

Expert Intelligence is a company working with data, and with geographies. These are our tools.

This is an experimental v0.1, which currently serves no function other than testing.

You (Mac) may also need to install lxml to use this, which will need to be downloaded separately first.

```
xcode-select --install
pip install lxml==4.9.2
```