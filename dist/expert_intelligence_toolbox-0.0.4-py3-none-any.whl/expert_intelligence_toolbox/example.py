import pandas as pd


def add_integers(a, b):
    return a + b

